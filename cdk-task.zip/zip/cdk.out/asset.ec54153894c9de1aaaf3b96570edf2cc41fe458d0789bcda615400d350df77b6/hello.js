const Aws  = require('aws-cdk-lib');
const { JsonableValue } = require("ts-jest");

exports.handler = async (event)=> {
    const s3=new Aws.S3();
    const myBuckets= await s3.listBuckets().promise();
    console.log(myBuckets);
    const response={
        statusCode:200,
        body: JsonableValue.stringify('Hello'),
    };
    return response;
  };

  